package com.grupo11.tiendaderopa.interfaces;

public interface Command {
    void ejecutar();
}