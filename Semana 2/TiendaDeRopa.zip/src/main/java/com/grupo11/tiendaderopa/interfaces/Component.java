package com.grupo11.tiendaderopa.interfaces;

public interface Component {
    double getPrice();
    String getDescription();
}